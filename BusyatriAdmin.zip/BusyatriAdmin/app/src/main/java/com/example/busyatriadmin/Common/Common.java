package com.example.busyatriadmin.Common;

import com.example.busyatriadmin.Model.Users;

public class Common {
    public static Users currentUser;
}
